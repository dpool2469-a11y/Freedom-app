(() => {
  "use strict";
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const money = value => {
    const n = Number(value || 0);
    return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
  };
  const todayISO = () => new Date().toISOString().slice(0, 10);
  const uid = () => (crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const state = { debts: [], transactions: [], goals: [], settings: {}, page: "home", filter: "all", hideAmounts: false, modalSubmit: null };
  let toastTimer;

  function toast(message) {
    const node = $("#toast");
    node.textContent = message;
    node.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => node.classList.remove("show"), 2400);
  }
  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
  }
  function num(value) { return Math.max(0, Number(value) || 0); }
  function monthStart() { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-01`; }
  function inCurrentMonth(date) { return String(date || "").slice(0,7) === todayISO().slice(0,7); }
  function sum(items, key) { return items.reduce((total, item) => total + num(item[key]), 0); }
  function getSetting(key, fallback = null) { return Object.prototype.hasOwnProperty.call(state.settings, key) ? state.settings[key] : fallback; }
  async function saveSetting(key, value) { state.settings[key] = value; await FreedomDB.put("settings", { key, value }); }
  function amountText(selector, value) { const el = $(selector); if (el) el.textContent = money(value); }

  async function loadState() {
    const [debts, transactions, goals, settings] = await Promise.all([
      FreedomDB.getAll("debts"), FreedomDB.getAll("transactions"), FreedomDB.getAll("goals"), FreedomDB.getAll("settings")
    ]);
    state.debts = debts;
    state.transactions = transactions;
    state.goals = goals;
    state.settings = {};
    settings.forEach(item => state.settings[item.key] = item.value);
    state.hideAmounts = !!getSetting("hideAmounts", false);
    updateHideUI();
    renderAll();
  }

  function navigate(page) {
    state.page = page;
    $$(".page").forEach(el => el.classList.toggle("active", el.id === `page-${page}`));
    $$(".nav-item").forEach(el => el.classList.toggle("active", el.dataset.page === page));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function renderAll() {
    renderHome(); renderDebts(); renderBudget(); renderGoals(); renderProfile();
    $("#todayLabel").textContent = new Date().toLocaleDateString("en-US", { month: "short", day: "2-digit" }).toUpperCase();
    $("#monthLabel").textContent = new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" }).toUpperCase();
    applyAmountMask();
  }

  function monthTransactions() { return state.transactions.filter(t => inCurrentMonth(t.date)); }
  function totals() {
    const monthly = monthTransactions();
    const income = sum(monthly.filter(t => t.type === "income"), "amount");
    const expenses = sum(monthly.filter(t => t.type === "expense"), "amount");
    const debt = sum(state.debts, "balance");
    const saved = sum(state.goals, "saved");
    const budget = num(getSetting("monthlyBudget", 0));
    return { income, expenses, debt, saved, budget, budgetLeft: budget ? budget - expenses : 0, net: saved - debt };
  }

  function renderHome() {
    const t = totals();
    amountText("#netPosition", t.net); amountText("#homeDebt", t.debt); amountText("#homeSavings", t.saved);
    amountText("#homeIncome", t.income); amountText("#homeExpenses", t.expenses);
    $("#homeBudgetLeft").textContent = t.budget ? money(t.budgetLeft) : "Not set";
    const futureDebts = state.debts.filter(d => d.dueDate && d.dueDate >= todayISO()).sort((a,b) => a.dueDate.localeCompare(b.dueDate));
    const next = futureDebts[0];
    $("#nextPayment").textContent = next ? `${next.name} · ${new Date(`${next.dueDate}T00:00:00`).toLocaleDateString("en-IN",{day:"numeric",month:"short"})}` : "Nothing due";
    const move = $("#nextMove");
    if (!state.debts.length && !state.transactions.length && !state.goals.length) {
      move.innerHTML = `<div class="move-symbol">＋</div><div class="move-copy"><strong>Your journey starts here</strong><p>Add a debt, transaction, or savings goal to make this dashboard yours.</p><div class="record-actions" style="justify-content:flex-start"><button class="mini-btn" data-quick="debt">＋ Debt</button><button class="mini-btn" data-quick="transaction">＋ Transaction</button><button class="mini-btn" data-quick="goal">＋ Goal</button></div></div>`;
    } else if (t.debt > 0) {
      move.innerHTML = `<div class="move-symbol">↘</div><div class="move-copy"><strong>Keep moving forward</strong><p>You have ${money(t.debt)} in recorded debt. Review your balances and choose a repayment priority.</p><button class="mini-btn" data-goto="debt">Review debts ↗</button></div>`;
    } else {
      move.innerHTML = `<div class="move-symbol">✓</div><div class="move-copy"><strong>Keep your momentum</strong><p>Your records are in place. Keep tracking spending and building your savings goals.</p><button class="mini-btn" data-goto="savings">View savings ↗</button></div>`;
    }
    const recent = [...state.transactions].sort((a,b) => (b.date || "").localeCompare(a.date || "")).slice(0,4);
    $("#recentActivity").innerHTML = recent.length ? recent.map(t => activityHTML(t)).join("") : `<div class="empty-state">No activity yet. Add your first transaction.</div>`;
  }

  function activityHTML(t) {
    const income = t.type === "income";
    return `<div class="activity-row"><div class="record-icon ${income ? "green-icon" : "red-icon"}">${income ? "↗" : "↘"}</div><div class="record-main"><strong>${escapeHTML(t.title)}</strong><small>${escapeHTML(t.category || (income ? "Income" : "Expense"))} · ${escapeHTML(t.date || "")}</small></div><div class="record-right"><strong class="amount ${income ? "positive" : ""}">${income ? "+" : "−"}${money(t.amount)}</strong></div></div>`;
  }

  function renderDebts() {
    const total = sum(state.debts, "balance");
    amountText("#debtTotal", total);
    $("#debtCount").textContent = state.debts.length ? `${state.debts.length} active record${state.debts.length === 1 ? "" : "s"} · update balances after payments` : "No debts added yet";
    const original = sum(state.debts, "original");
    const paidPercent = original > 0 ? Math.max(0, Math.min(100, ((original - total) / original) * 100)) : 0;
    $("#debtProgress").style.width = `${paidPercent}%`;
    $("#debtList").innerHTML = state.debts.length ? [...state.debts].sort((a,b) => (Number(b.rate)||0) - (Number(a.rate)||0)).map(d => `
      <article class="record-card"><div class="record-icon">↘</div><div class="record-main"><strong>${escapeHTML(d.name)}</strong><small>${escapeHTML(d.kind)} · ${Number(d.rate||0).toFixed(2)}% APR${d.dueDate ? ` · Due ${escapeHTML(d.dueDate)}` : ""}</small><small>Minimum payment: ${money(d.payment)}</small></div><div class="record-right"><strong class="amount">${money(d.balance)}</strong><small>outstanding</small><div class="record-actions"><button class="mini-btn" data-edit-debt="${d.id}">Edit</button><button class="mini-btn danger" data-delete-debt="${d.id}">Delete</button></div></div></article>`).join("") : `<div class="empty-state">Nothing here yet. Add a loan or credit-card balance to get started.</div>`;
  }

  function renderBudget() {
    const monthly = monthTransactions();
    const expenses = sum(monthly.filter(t => t.type === "expense"), "amount");
    const budget = num(getSetting("monthlyBudget", 0));
    amountText("#budgetSpent", expenses);
    $("#budgetLimitLabel").textContent = budget ? `Monthly limit: ${money(budget)}` : "No monthly limit set";
    $("#budgetRemaining").textContent = budget ? `${money(budget-expenses)} ${budget-expenses < 0 ? "over" : "left"}` : "Set a limit";
    $("#budgetProgress").style.width = budget ? `${Math.min(100, expenses / budget * 100)}%` : "0%";
    $("#budgetProgress").style.background = budget && expenses > budget ? "var(--red)" : "var(--green)";
    $("#profileBudgetValue").textContent = budget ? money(budget) : "Not set";
    let list = [...state.transactions].sort((a,b) => (b.date || "").localeCompare(a.date || ""));
    if (state.filter !== "all") list = list.filter(t => t.type === state.filter);
    $("#transactionList").innerHTML = list.length ? list.map(t => `
      <article class="record-card"><div class="record-icon ${t.type === "income" ? "green-icon" : "red-icon"}">${t.type === "income" ? "↗" : "↘"}</div><div class="record-main"><strong>${escapeHTML(t.title)}</strong><small>${escapeHTML(t.category || (t.type === "income" ? "Income" : "Expense"))} · ${escapeHTML(t.date || "")}</small></div><div class="record-right"><strong class="amount ${t.type === "income" ? "positive" : ""}">${t.type === "income" ? "+" : "−"}${money(t.amount)}</strong><div class="record-actions"><button class="mini-btn" data-edit-transaction="${t.id}">Edit</button><button class="mini-btn danger" data-delete-transaction="${t.id}">Delete</button></div></div></article>`).join("") : `<div class="empty-state">No ${state.filter === "all" ? "" : state.filter + " "}transactions yet.</div>`;
    $$(".filter-btn").forEach(btn => btn.classList.toggle("selected", btn.dataset.filter === state.filter));
  }

  function renderGoals() {
    const saved = sum(state.goals, "saved");
    amountText("#savingsTotal", saved);
    $("#goalCount").textContent = state.goals.length ? `${state.goals.length} goal${state.goals.length === 1 ? "" : "s"} in progress` : "No goals yet";
    $("#goalList").innerHTML = state.goals.length ? state.goals.map(g => {
      const percent = Number(g.target) > 0 ? Math.max(0, Math.min(100, Number(g.saved) / Number(g.target) * 100)) : 0;
      return `<article class="record-card goal-card"><div class="record-icon green-icon">◉</div><div class="record-main"><strong>${escapeHTML(g.name)}</strong><small>${money(g.saved)} saved of ${money(g.target)}</small><div class="progress-track"><span style="width:${percent}%"></span></div><small>${Math.round(percent)}% complete${g.deadline ? ` · Target ${escapeHTML(g.deadline)}` : ""}</small></div><div class="record-right"><div class="record-actions"><button class="mini-btn" data-add-to-goal="${g.id}">＋ Add</button><button class="mini-btn" data-edit-goal="${g.id}">Edit</button><button class="mini-btn danger" data-delete-goal="${g.id}">×</button></div></div></article>`;
    }).join("") : `<div class="empty-state">Create your first goal, from an emergency fund to something you've been planning for.</div>`;
  }

  function renderProfile() {
    $("#profileBudgetValue").textContent = num(getSetting("monthlyBudget", 0)) ? money(getSetting("monthlyBudget")) : "Not set";
    $("#backupReminderValue").textContent = getSetting("backupReminder", true) ? "Reminder prompt enabled" : "Off";
  }

  function applyAmountMask() { $$(".amount").forEach(el => el.classList.toggle("masked", state.hideAmounts)); }
  function updateHideUI() {
    $("#toggleAmounts").textContent = state.hideAmounts ? "⊘" : "◉";
    $("#toggleAmounts").title = state.hideAmounts ? "Show amounts" : "Hide amounts";
  }

  function field(name, label, type = "text", options = {}) {
    const required = options.required ? "required" : "";
    const value = options.value !== undefined && options.value !== null ? ` value="${escapeHTML(options.value)}"` : "";
    const min = options.min !== undefined ? ` min="${options.min}"` : "";
    const max = options.max !== undefined ? ` max="${options.max}"` : "";
    const step = options.step ? ` step="${options.step}"` : "";
    const placeholder = options.placeholder ? ` placeholder="${escapeHTML(options.placeholder)}"` : "";
    if (type === "select") {
      const opts = (options.choices || []).map(([v,l]) => `<option value="${escapeHTML(v)}"${String(options.value)===String(v)?" selected":""}>${escapeHTML(l)}</option>`).join("");
      return `<div class="form-field"><label for="field-${name}">${label}</label><select id="field-${name}" name="${name}" ${required}>${opts}</select></div>`;
    }
    return `<div class="form-field"><label for="field-${name}">${label}</label><input id="field-${name}" name="${name}" type="${type}"${value}${min}${max}${step}${placeholder} ${required}></div>`;
  }

  function openModal(title, fieldsHTML, submitLabel, handler) {
    $("#modalTitle").textContent = title;
    $("#modalFields").innerHTML = fieldsHTML;
    $("#submitModal").textContent = submitLabel || "Save record";
    state.modalSubmit = handler;
    $("#modalBackdrop").hidden = false;
    document.body.style.overflow = "hidden";
    setTimeout(() => $("#modalFields input, #modalFields select")?.focus(), 50);
  }
  function closeModal() { $("#modalBackdrop").hidden = true; document.body.style.overflow = ""; state.modalSubmit = null; }
  function formData(form) { return Object.fromEntries(new FormData(form).entries()); }

  function openDebtForm(existing = null) {
    const d = existing || {};
    openModal(existing ? "Edit debt" : "Add debt", `
      ${field("name","Debt name","text",{required:true,value:d.name,placeholder:"e.g. Personal loan"})}
      ${field("kind","Debt type","select",{required:true,value:d.kind||"Personal loan",choices:[["Personal loan","Personal loan"],["Credit card","Credit card"],["Home loan","Home loan"],["Vehicle loan","Vehicle loan"],["Education loan","Education loan"],["Family / friend","Family / friend"],["Other","Other"]]})}
      <div class="form-grid">${field("original","Original amount (₹)","number",{required:true,min:0,step:"0.01",value:d.original})}${field("balance","Outstanding balance (₹)","number",{required:true,min:0,step:"0.01",value:d.balance})}</div>
      <div class="form-grid">${field("rate","Annual interest rate (%)","number",{min:0,step:"0.01",value:d.rate||0})}${field("payment","Minimum monthly payment (₹)","number",{min:0,step:"0.01",value:d.payment||0})}</div>
      ${field("dueDate","Next due date (optional)","date",{value:d.dueDate||""})}
      <div class="field-help">Estimates depend on accurate balances, rates, payment amounts, and lender rules. This tracker does not replace your lender's statement.</div>
    `, existing ? "Save changes" : "Add debt", async raw => {
      const x = formData(raw);
      const record = { id: d.id || uid(), name: x.name.trim(), kind: x.kind, original: num(x.original), balance: num(x.balance), rate: num(x.rate), payment: num(x.payment), dueDate: x.dueDate || "", updatedAt: new Date().toISOString() };
      await FreedomDB.put("debts", record); closeModal(); await loadState(); toast(existing ? "Debt updated" : "Debt added");
    });
  }

  function openTransactionForm(existing = null) {
    const t = existing || {};
    openModal(existing ? "Edit transaction" : "Add transaction", `
      ${field("type","Transaction type","select",{required:true,value:t.type||"expense",choices:[["expense","Expense"],["income","Income"]]})}
      ${field("title","Description","text",{required:true,value:t.title,placeholder:"e.g. Groceries or salary"})}
      <div class="form-grid">${field("amount","Amount (₹)","number",{required:true,min:0.01,step:"0.01",value:t.amount})}${field("date","Date","date",{required:true,value:t.date||todayISO()})}</div>
      ${field("category","Category","select",{required:true,value:t.category||(t.type==="income"?"Salary":"Food"),choices:[["Salary","Salary"],["Freelance","Freelance"],["Housing","Housing"],["Food","Food"],["Transport","Transport"],["Bills","Bills"],["Health","Health"],["Shopping","Shopping"],["Education","Education"],["Entertainment","Entertainment"],["Debt payment","Debt payment"],["Savings contribution","Savings contribution"],["Other","Other"]]})}
    `, existing ? "Save changes" : "Add transaction", async raw => {
      const x = formData(raw);
      const record = { id: t.id || uid(), type: x.type, title: x.title.trim(), amount: num(x.amount), date: x.date, category: x.category, updatedAt: new Date().toISOString() };
      await FreedomDB.put("transactions", record); closeModal(); await loadState(); toast(existing ? "Transaction updated" : "Transaction added");
    });
  }

  function openGoalForm(existing = null) {
    const g = existing || {};
    openModal(existing ? "Edit savings goal" : "Create savings goal", `
      ${field("name","Goal name","text",{required:true,value:g.name,placeholder:"e.g. Emergency fund"})}
      <div class="form-grid">${field("target","Target amount (₹)","number",{required:true,min:1,step:"0.01",value:g.target})}${field("saved","Already saved (₹)","number",{required:true,min:0,step:"0.01",value:g.saved||0})}</div>
      ${field("deadline","Target date (optional)","date",{value:g.deadline||""})}
    `, existing ? "Save changes" : "Create goal", async raw => {
      const x = formData(raw);
      const record = { id: g.id || uid(), name: x.name.trim(), target: num(x.target), saved: num(x.saved), deadline: x.deadline || "", updatedAt: new Date().toISOString() };
      await FreedomDB.put("goals", record); closeModal(); await loadState(); toast(existing ? "Goal updated" : "Goal created");
    });
  }

  function openBudgetForm() {
    const current = num(getSetting("monthlyBudget", 0));
    openModal("Monthly budget limit", `${field("budget","How much can you spend this month? (₹)","number",{required:true,min:0,step:"0.01",value:current,placeholder:"0"})}<div class="field-help">This limit compares against transactions marked as expenses in the current calendar month.</div>`, "Save limit", async raw => {
      const x = formData(raw); await saveSetting("monthlyBudget", num(x.budget)); closeModal(); renderAll(); toast("Budget limit saved");
    });
  }

  function addToGoal(id) {
    const g = state.goals.find(item => item.id === id); if (!g) return;
    openModal("Add savings progress", `${field("contribution","Amount to add (₹)","number",{required:true,min:0.01,step:"0.01",placeholder:"0"})}<div class="field-help">This updates the goal's saved amount. It does not automatically create a bank transfer or transaction.</div>`, "Add progress", async raw => {
      const x = formData(raw); g.saved = num(g.saved) + num(x.contribution); g.updatedAt = new Date().toISOString();
      await FreedomDB.put("goals", g); closeModal(); await loadState(); toast("Savings progress updated");
    });
  }

  async function deleteRecord(store, id, label) {
    if (!confirm(`Delete this ${label}? This cannot be undone unless you have a backup.`)) return;
    await FreedomDB.remove(store, id); await loadState(); toast(`${label[0].toUpperCase()+label.slice(1)} deleted`);
  }

  async function exportBackup() {
    const data = await FreedomDB.exportAll();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `FREEDOM-backup-${todayISO()}.json`;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    await saveSetting("lastBackupDate", todayISO());
    toast("Backup export started. Save the file somewhere safe.");
  }

  async function importBackup(file) {
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (!confirm("Restoring replaces the current FREEDOM records on this device. Export a backup first if you need the current data. Continue?")) return;
      await FreedomDB.importAll(data); await loadState(); toast("Backup restored successfully");
    } catch (err) {
      alert(`Could not restore backup: ${err.message || "Invalid file"}`);
    } finally { $("#importFile").value = ""; }
  }

  async function firstLaunch() {
    if (getSetting("onboardingSeen", false)) return;
    openModal("Welcome to FREEDOM", `
      <div class="welcome-block"><div class="welcome-word">FREEDOM<span>.</span></div><p>Take control. Live free.</p><p class="muted">Manage debt, understand spending, and build your future. Your records stay on this device unless you export them.</p></div>
      <div class="onboarding-choice"><button type="button" class="choice-card" id="setupChoice"><strong>GET STARTED ↗</strong><small>Set up your finances in a few steps.</small></button><button type="button" class="choice-card" id="exploreChoice"><strong>EXPLORE FREEDOM</strong><small>Skip setup and add details whenever you're ready.</small></button></div>
    `, "Continue", async () => { await saveSetting("onboardingSeen", true); closeModal(); });
    $("#submitModal").style.display = "none";
    $("#cancelModal").textContent = "Close";
    $("#setupChoice").addEventListener("click", () => { closeModal(); openSetup(); });
    $("#exploreChoice").addEventListener("click", async () => { await saveSetting("onboardingSeen", true); closeModal(); });
  }

  function openSetup() {
    openModal("Quick setup", `
      <p class="muted small">Every step is optional. You can change these details later.</p>
      ${field("income","Approximate monthly income (₹)","number",{min:0,step:"0.01",value:"",placeholder:"Skip if you prefer"})}
      ${field("debt","Total debt outstanding (₹)","number",{min:0,step:"0.01",value:"",placeholder:"0"})}
      ${field("expenses","Approximate monthly expenses (₹)","number",{min:0,step:"0.01",value:"",placeholder:"0"})}
      ${field("savings","Current savings / emergency fund (₹)","number",{min:0,step:"0.01",value:"",placeholder:"0"})}
      <div class="field-help">For a simple starting point, income and expenses are added as setup transactions. Debt and savings amounts can be recorded as a starter debt/goal so you can edit details later.</div>
    `, "Finish setup", async raw => {
      const x = formData(raw);
      const jobs = [];
      if (num(x.income) > 0) jobs.push(FreedomDB.put("transactions", { id:uid(), type:"income", title:"Setup income", amount:num(x.income), date:todayISO(), category:"Salary", updatedAt:new Date().toISOString() }));
      if (num(x.expenses) > 0) jobs.push(FreedomDB.put("transactions", { id:uid(), type:"expense", title:"Setup expenses", amount:num(x.expenses), date:todayISO(), category:"Other", updatedAt:new Date().toISOString() }));
      if (num(x.debt) > 0) jobs.push(FreedomDB.put("debts", { id:uid(), name:"Debt balance (edit details)", kind:"Other", original:num(x.debt), balance:num(x.debt), rate:0, payment:0, dueDate:"", updatedAt:new Date().toISOString() }));
      if (num(x.savings) > 0) jobs.push(FreedomDB.put("goals", { id:uid(), name:"Existing savings", target:num(x.savings), saved:num(x.savings), deadline:"", updatedAt:new Date().toISOString() }));
      await Promise.all(jobs); await saveSetting("onboardingSeen", true); closeModal(); await loadState(); toast("Welcome to FREEDOM");
    });
  }

  function bindEvents() {
    $$(".nav-item").forEach(btn => btn.addEventListener("click", () => navigate(btn.dataset.page)));
    $$("[data-page-link]").forEach(btn => btn.addEventListener("click", e => { e.preventDefault(); navigate(btn.dataset.pageLink); }));
    $("#settingsBtn").addEventListener("click", () => navigate("profile"));
    $("#toggleAmounts").addEventListener("click", async () => { state.hideAmounts = !state.hideAmounts; await saveSetting("hideAmounts", state.hideAmounts); updateHideUI(); applyAmountMask(); });
    $("#addDebtBtn").addEventListener("click", () => openDebtForm());
    $("#addTransactionBtn").addEventListener("click", () => openTransactionForm());
    $("#addGoalBtn").addEventListener("click", () => openGoalForm());
    $("#setBudgetBtn").addEventListener("click", openBudgetForm);
    $("#profileBudgetBtn").addEventListener("click", openBudgetForm);
    $("#profileHideBtn").addEventListener("click", async () => { state.hideAmounts = !state.hideAmounts; await saveSetting("hideAmounts", state.hideAmounts); updateHideUI(); applyAmountMask(); });
    $("#profileCurrencyBtn").addEventListener("click", () => toast("This first version uses Indian Rupees (INR)."));
    $("#exportBtn").addEventListener("click", exportBackup);
    $("#importBtn").addEventListener("click", () => $("#importFile").click());
    $("#importFile").addEventListener("change", e => importBackup(e.target.files[0]));
    $("#backupReminderBtn").addEventListener("click", async () => {
      const enabled = !getSetting("backupReminder", true); await saveSetting("backupReminder", enabled); renderProfile();
      toast(enabled ? "Backup reminder prompts enabled" : "Backup reminder prompts turned off");
    });
    $("#clearDataBtn").addEventListener("click", async () => {
      if (!confirm("Delete ALL FREEDOM records and settings from this device? Export a backup first if needed.")) return;
      if (!confirm("Final confirmation: permanently delete local data?")) return;
      await FreedomDB.clearAll(); await loadState(); toast("Local data deleted");
    });
    $("#closeModal").addEventListener("click", closeModal);
    $("#cancelModal").addEventListener("click", closeModal);
    $("#modalBackdrop").addEventListener("click", e => { if (e.target === $("#modalBackdrop")) closeModal(); });
    $("#modalForm").addEventListener("submit", async e => {
      e.preventDefault(); if (!state.modalSubmit) return;
      try { await state.modalSubmit(e.currentTarget); } catch (err) { alert(`Could not save: ${err.message || err}`); }
    });
    document.addEventListener("click", e => {
      const quick = e.target.closest("[data-quick]");
      if (quick) { const type = quick.dataset.quick; if(type==="debt") openDebtForm(); if(type==="transaction") openTransactionForm(); if(type==="goal") openGoalForm(); }
      const goto = e.target.closest("[data-goto]");
      if (goto) navigate(goto.dataset.goto);
      const editDebt = e.target.closest("[data-edit-debt]");
      if (editDebt) openDebtForm(state.debts.find(d => d.id === editDebt.dataset.editDebt));
      const delDebt = e.target.closest("[data-delete-debt]");
      if (delDebt) deleteRecord("debts", delDebt.dataset.deleteDebt, "debt");
      const editTx = e.target.closest("[data-edit-transaction]");
      if (editTx) openTransactionForm(state.transactions.find(t => t.id === editTx.dataset.editTransaction));
      const delTx = e.target.closest("[data-delete-transaction]");
      if (delTx) deleteRecord("transactions", delTx.dataset.deleteTransaction, "transaction");
      const editGoal = e.target.closest("[data-edit-goal]");
      if (editGoal) openGoalForm(state.goals.find(g => g.id === editGoal.dataset.editGoal));
      const delGoal = e.target.closest("[data-delete-goal]");
      if (delGoal) deleteRecord("goals", delGoal.dataset.deleteGoal, "goal");
      const addGoal = e.target.closest("[data-add-to-goal]");
      if (addGoal) addToGoal(addGoal.dataset.addToGoal);
    });
    $$(".filter-btn").forEach(btn => btn.addEventListener("click", () => { state.filter = btn.dataset.filter; renderBudget(); }));
  }

  async function init() {
    bindEvents();
    try {
      await loadState();
      if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
        navigator.serviceWorker.register("./service-worker.js").catch(() => {});
      }
      const lastBackup = getSetting("lastBackupDate");
      if (getSetting("backupReminder", true) && state.transactions.length + state.debts.length + state.goals.length > 0) {
        const days = lastBackup ? Math.floor((Date.now() - new Date(lastBackup).getTime()) / 86400000) : 30;
        if (days >= 30) setTimeout(() => toast("Backup reminder: export a copy of your FREEDOM data."), 1500);
      }
      await firstLaunch();
    } catch (err) {
      console.error(err);
      alert(`FREEDOM could not open its local database. Please use an up-to-date browser. Details: ${err.message || err}`);
    }
  }
  document.addEventListener("DOMContentLoaded", init);
})();

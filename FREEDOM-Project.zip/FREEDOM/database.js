/* FREEDOM local-first database. Data remains in this browser/device profile. */
(function () {
  const DB_NAME = "freedom-local-db";
  const DB_VERSION = 1;
  const STORE_NAMES = ["debts", "transactions", "goals", "settings"];
  let dbPromise;

  function openDB() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      if (!("indexedDB" in window)) {
        reject(new Error("This browser does not support IndexedDB. Please use a modern browser."));
        return;
      }
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains("debts")) db.createObjectStore("debts", { keyPath: "id" });
        if (!db.objectStoreNames.contains("transactions")) db.createObjectStore("transactions", { keyPath: "id" });
        if (!db.objectStoreNames.contains("goals")) db.createObjectStore("goals", { keyPath: "id" });
        if (!db.objectStoreNames.contains("settings")) db.createObjectStore("settings", { keyPath: "key" });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("Unable to open local database."));
    });
    return dbPromise;
  }

  async function getAll(storeName) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const request = db.transaction(storeName, "readonly").objectStore(storeName).getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  async function put(storeName, record) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, "readwrite");
      tx.objectStore(storeName).put(record);
      tx.oncomplete = () => resolve(record);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error("Database write aborted."));
    });
  }

  async function remove(storeName, id) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, "readwrite");
      tx.objectStore(storeName).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async function clearAll() {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAMES, "readwrite");
      STORE_NAMES.forEach(name => tx.objectStore(name).clear());
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async function exportAll() {
    const [debts, transactions, goals, settings] = await Promise.all([
      getAll("debts"), getAll("transactions"), getAll("goals"), getAll("settings")
    ]);
    return { app: "FREEDOM", formatVersion: 1, exportedAt: new Date().toISOString(), debts, transactions, goals, settings };
  }

  async function importAll(data) {
    if (!data || data.app !== "FREEDOM" || !Array.isArray(data.debts) ||
        !Array.isArray(data.transactions) || !Array.isArray(data.goals) || !Array.isArray(data.settings)) {
      throw new Error("This does not look like a valid FREEDOM backup.");
    }
    await clearAll();
    const jobs = [];
    data.debts.forEach(item => jobs.push(put("debts", item)));
    data.transactions.forEach(item => jobs.push(put("transactions", item)));
    data.goals.forEach(item => jobs.push(put("goals", item)));
    data.settings.forEach(item => jobs.push(put("settings", item)));
    await Promise.all(jobs);
  }

  window.FreedomDB = { openDB, getAll, put, remove, clearAll, exportAll, importAll };
})();

# FREEDOM — Take Control. Live Free.

FREEDOM is a local-first personal finance PWA prototype focused on debt tracking, budgets, transactions, and savings goals. It uses HTML, CSS, and vanilla JavaScript with IndexedDB.

## Included features
- Nothing OS-inspired black-and-white responsive interface
- Optional first-launch onboarding
- Local debt records (balance, rate, payment, due date)
- Income and expense transaction tracking
- Monthly expense budget limit
- Savings goals and contributions
- Hide amounts on screen
- JSON backup export and restore
- Local data deletion
- Basic offline app-shell caching
- PWA manifest and app icons

## Important limitations
- This is a first-version prototype, not a regulated financial product or a substitute for lender statements or professional advice.
- Debt payoff calculators/forecasts are not yet implemented. The interface only records debts and shows simple totals.
- Browser/device storage is not an automatic backup and may be lost if browser data is cleared, the device is lost, or the browser evicts storage. Export backups regularly and store them securely.
- The app does not encrypt the database itself, require an app PIN, sync to cloud, connect to banks, or send system notifications. Anyone with access to the same browser profile/device may be able to view stored records.
- The app uses INR as the default currency.
- Google Fonts is used for typography when internet access is available; system fallbacks are provided.
- GitHub Pages hosts static files only. It does not create private cloud storage for individual users.
- Before public release, test on target devices, review security/privacy, accessibility, financial calculation accuracy, and all relevant legal requirements.

## Run locally
For full PWA/service-worker behavior, serve over HTTPS or localhost. Opening `index.html` directly may allow basic page use, but service workers generally require a secure context.

## Deploy using GitHub on Android
1. Extract `FREEDOM-Project.zip` on your phone if needed.
2. Sign in to GitHub and create a new repository named `freedom-app` (public repositories are supported by GitHub Pages on the Free plan; verify current GitHub plan rules).
3. In the repository, choose **Add file → Upload files** and upload the *contents* of the `FREEDOM` folder, not the enclosing folder itself.
4. Commit the files to the `main` branch.
5. Open **Settings → Pages**.
6. Under build/deployment, select **Deploy from a branch**.
7. Select branch `main` and folder `/(root)`, then Save.
8. Wait for deployment and open the GitHub Pages URL shown on the Pages settings screen.
9. Open the site in Chrome on Android, then use the browser menu → **Add to Home screen** or **Install app** if available.

## Backup and restore
- Use **More → Export backup** to download a JSON file.
- Store it in a safe place. It contains sensitive financial information.
- Use **More → Restore backup** to restore it. Restoring replaces the current local records.
- Test restore with sample data before relying on backups.

## Suggested testing checklist
- Add, edit, and delete a debt.
- Add income and expense transactions.
- Set a monthly budget and verify spending totals.
- Create a savings goal and add progress.
- Hide and show amounts.
- Export a backup, clear test data, then restore the backup.
- Reload the page and confirm records remain.
- Test the app with airplane mode after the first successful load.
